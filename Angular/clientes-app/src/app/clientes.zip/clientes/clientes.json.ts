import { Cliente } from './cliente';

// export const CLIENTES: Cliente[] = [
//     { id: 1, nombre: 'duglas', apellido: 'Guebardo', email: 'mendez@gmail.com', createAt: '2024-04-05' },
//     { id: 2, nombre: 'Juan', apellido: 'Pérez', email: 'juan.perez@email.com', createAt: '2024-05-15' },
//     { id: 3, nombre: 'María', apellido: 'García', email: 'maria.garcia@email.com', createAt: '2024-06-22' },
//     { id: 4, nombre: 'Luis', apellido: 'Rodríguez', email: 'luis.rodriguez@email.com', createAt: '2024-07-08' },
//     { id: 5, nombre: 'Ana', apellido: 'López', email: 'ana.lopez@email.com', createAt: '2024-08-12' },
//     { id: 6, nombre: 'Carlos', apellido: 'Martínez', email: 'carlos.martinez@email.com', createAt: '2024-09-01' },
//     { id: 7, nombre: 'Marta', apellido: 'Sánchez', email: 'marta.sanchez@email.com', createAt: '2024-10-18' },
//     { id: 8, nombre: 'David', apellido: 'González', email: 'david.gonzalez@email.com', createAt: '2024-11-05' },
//     { id: 9, nombre: 'Sofía', apellido: 'Hernández', email: 'sofia.hernandez@email.com', createAt: '2023-12-29' },
//     { id: 10, nombre: 'Miguel', apellido: 'Díaz', email: 'miguel.diaz@email.com', createAt: '2023-11-17' },
//     { id: 11, nombre: 'Laura', apellido: 'Moreno', email: 'laura.moreno@email.com', createAt: '2023-10-24' },
//     { id: 12, nombre: 'Pablo', apellido: 'Muñoz', email: 'pablo.munoz@email.com', createAt: '2023-09-13' },
//     { id: 13, nombre: 'Sara', apellido: 'Álvarez', email: 'sara.alvarez@email.com', createAt: '2023-08-07' },
//     { id: 14, nombre: 'Javier', apellido: 'Romero', email: 'javier.romero@email.com', createAt: '2023-07-02' },
//     { id: 15, nombre: 'Andrea', apellido: 'Gómez', email: 'andrea.gomez@email.com', createAt: '2023-06-19' } 
//   ];